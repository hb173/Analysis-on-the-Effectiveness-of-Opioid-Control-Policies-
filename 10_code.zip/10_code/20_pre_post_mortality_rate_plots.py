# To add a new cell, type '# %%'
# To add a new markdown cell, type '# %% [markdown]'
# %%
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
import matplotlib_inline
from analysis_functions import plot_pre_post


matplotlib_inline.backend_inline.set_matplotlib_formats("svg")
plt.rcParams["font.size"] = 14

# %%
fl_mortality = pd.read_csv("../20_outputs/fl_mortality.csv", sep=",", index_col=0)
tx_mortality = pd.read_csv("../20_outputs/tx_mortality.csv", sep=",", index_col=0)
wa_mortality = pd.read_csv("../20_outputs/wa_mortality.csv", sep=",", index_col=0)

# %% [markdown]
# ### Plot Pre-Post Policy for Florida, Texas, and Washington
# %% [markdown]
# #### Florida

# %%
# seperate to pre and post policy periods for FL

x_pre_fl = np.array(fl_mortality[fl_mortality["Year"] < 2010]["Year"])
y_pre_fl = np.array(fl_mortality[fl_mortality["Year"] < 2010]["Mortality Rate"])

x_post_fl = np.array(fl_mortality[fl_mortality["Year"] >= 2010]["Year"])
y_post_fl = np.array(fl_mortality[fl_mortality["Year"] >= 2010]["Mortality Rate"])


# %%
# plot the figure


# def plot_pre_post(State_ABBR, x_pre, y_pre, x_post, y_post, policy_year, ax=None):
#     import warnings
#     warnings.filterwarnings("ignore")

#     if ax is None:
#         fig, ax = plt.subplots(figsize=(8, 5))


#     x_pre = x_pre - policy_year
#     x_post = x_post - policy_year

#     ax = sns.regplot(x_pre, y_pre, ci=95, scatter=False, color="r")
#     # m, b = np.polyfit(x_post, y_post, 1)
#     # plt.plot(x_post, m * x_post + b)
#     ax = sns.regplot(x_post, y_post, ci=95, scatter=False, color="r")
#     ax.set_xlabel("Years from policy change")
#     ax.set_ylabel("Mortality Rate")
#     ax.set_title(State_ABBR + " Pre-Post Model Graph", weight="bold")
#     ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda y, _: "{:.4%}".format(y)))

#     ax.axvline(x=0, color="black", ls="--")
#     ax.text(policy_year + 0.1, y_post.mean() * 0.80, "Policy Change", fontsize=12)
#     ax.text(2003.2, y_pre.mean() * 1.1, "CI:95%", fontsize=10)

#     ax.grid(b=True, which="major", color="#999999", linestyle="-", alpha=0.2)
#     sns.despine()
#     plt.tight_layout()
#     plt.show()


# %%
plot_pre_post("FL", x_pre_fl, y_pre_fl, x_post_fl, y_post_fl, 2010)

# %% [markdown]
# #### Texas

# %%
# seperate to pre and post policy periods for TX

x_pre_tx = np.array(tx_mortality[tx_mortality["Year"] < 2007]["Year"])
y_pre_tx = np.array(tx_mortality[tx_mortality["Year"] < 2007]["Mortality Rate"])

x_post_tx = np.array(tx_mortality[tx_mortality["Year"] >= 2007]["Year"])
y_post_tx = np.array(tx_mortality[tx_mortality["Year"] >= 2007]["Mortality Rate"])


# %%
plot_pre_post("TX", x_pre_tx, y_pre_tx, x_post_tx, y_post_tx, 2007)

# %% [markdown]
# #### Washington

# %%
# seperate to pre and post policy periods for WA

x_pre_wa = np.array(wa_mortality[wa_mortality["Year"] < 2012]["Year"])
y_pre_wa = np.array(wa_mortality[wa_mortality["Year"] < 2012]["Mortality Rate"])

x_post_wa = np.array(wa_mortality[wa_mortality["Year"] >= 2012]["Year"])
y_post_wa = np.array(wa_mortality[wa_mortality["Year"] >= 2012]["Mortality Rate"])


# %%
plot_pre_post("WA", x_pre_wa, y_pre_wa, x_post_wa, y_post_wa, 2012)
