# To add a new cell, type '# %%'
# To add a new markdown cell, type '# %% [markdown]'
# %%
import pandas as pd
import numpy as np
from dataCleaningFunctions import *

# %%
df = read_concat_mortality()

# %%
fl_mortality = clean_mortality(df, "FL")
fl_pop_pre_policy = pd.read_excel(
    "../00_source_data/Population/FL_and_comparison_states/fl_pop_2000-2009.xls", header=[3]
)
fl_pop_post_policy = pd.read_excel(
    "../00_source_data/Population/FL_and_comparison_states/fl_pop_2010-2019.xlsx", header=[3]
)
fl_pop = clean_pop(fl_pop_pre_policy, fl_pop_post_policy, "FL")
fl = merge_mortalitypop(fl_mortality, fl_pop)
fl


# %%
fl_mortality = fl.to_csv("../20_outputs/fl_mortality.csv")



# %%
tx_mortality = clean_mortality(df, "TX")

#%%
tx_pop_pre_policy = pd.read_excel(
    "../00_source_data/Population/TX_and_comparison_states/tx_pop_2000-2009.xls", header=[3]
)

tx_pop_post_policy = pd.read_excel(
    "../00_source_data/Population/TX_and_comparison_states/tx_pop_2010-2019.xlsx", header=[3]
)
tx_pop = clean_pop(tx_pop_pre_policy, tx_pop_post_policy, "TX")

#%%
tx = merge_mortalitypop(tx_mortality, tx_pop)
tx


# %%
tx_mortality = tx.to_csv("../20_outputs/tx_mortality.csv")


# %%
wa_mortality = clean_mortality(df, "WA")
wa_pop_pre_policy = pd.read_excel(
    "../00_source_data/Population/WA_and_comparison_states/wa_pop_2000-2009.xls", header=[3]
)
wa_pop_post_policy = pd.read_excel(
    "../00_source_data/Population/WA_and_comparison_states/wa_pop_2010-2019.xlsx", header=[3]
)
wa_pop = clean_pop(wa_pop_pre_policy, wa_pop_post_policy, "WA")
wa = merge_mortalitypop(wa_mortality, wa_pop)
wa


# %%
wa_mortality = wa.to_csv("../20_outputs/wa_mortality.csv")
