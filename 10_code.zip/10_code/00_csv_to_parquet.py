#%%
import pandas as pd

##### SETTINGS #####
STATE = "KS".lower()
LOAD_RAW_CSV = False

cols_of_interest = {
    "DRUG_NAME": "category",
    "QUANTITY": "uint16",
    "STRENGTH": "float",
    "TRANSACTION_DATE": "datetime64",
    "BUYER_COUNTY": "category",
    "BUYER_STATE": "category",
    "NDC_NO": "string",
    "DOSAGE_UNIT": "float",
    "MME_Conversion_Factor": "float",
    "dos_str": "float",
}


if LOAD_RAW_CSV:
    print("[INFO] Loading raw csv")
    df = pd.read_csv(
        f"../00_source_data/arcos-{STATE}-statewide-itemized.csv",
        usecols=cols_of_interest.keys(),
    )

    # dtype conversions
    df["TRANSACTION_DATE"] = pd.to_datetime(df["TRANSACTION_DATE"], format="%m%d%Y")
    for col in cols_of_interest.keys():
        df[col] = df[col].astype(cols_of_interest[col])

    # colnames to lowercase
    df.columns = [col.lower() for col in df.columns]
    df.head()

    # impute NA dos_str
    df['dos_str'] = df['dos_str'].fillna(df["dos_str"].mode().iloc[0])


    # calculate final variable
    df = df.assign(drug_qty=df["mme_conversion_factor"] * df["dos_str"] * df["dosage_unit"])

    df.to_parquet(
        path=f"../20_outputs/arcos-{STATE}-statewide-itemized-singlefile.parquet",
        engine="pyarrow",
    )
else:
    print("[INFO] Loading prepared parquet")
    df = pd.read_parquet(f"../20_outputs/arcos-{STATE}-statewide-itemized-singlefile.parquet")

#%%
# Assert homogenous state data
assert (df["buyer_state"] == STATE.upper()).all()

#%%
# Print data frame summary
na_pct = (df.isna().sum() / len(df)).to_dict()
print(f"{' SUMMARY ':=^80}")
print(f"- Date range: {df.transaction_date.min()} - {df.transaction_date.max()}")
print(f"- Unique drugs: {df.drug_name.unique().tolist()}")
print(f"- Number of counties: {df['buyer_county'].nunique()}")
print("- NA Stats (% NA):")
for k, v in na_pct.items():
    print(f"    - {k:<20}: {v:.1%}")
print(f"=" * 80)
