#%%
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
# sns.set_context("talk")
import matplotlib_inline
matplotlib_inline.backend_inline.set_matplotlib_formats("svg")

STATE="WA"

if STATE == "FL":
    print("Using FL!")
    comparison_states = ["FL", "IL" "MS", "GA"]
else:
    print("Using WA!")
    comparison_states = ["WA", "IL", "KS"]  # missing: CA


#%%
df = pd.concat(
    [
        pd.read_parquet(
            path=f"../20_outputs/arcos-{state.lower()}-statewide-itemized-singlefile.parquet"
        )
        for state in comparison_states
    ]
)

df.to_parquet(f"../20_outputs/all_shipments_{STATE}.parquet")

#%%
yearly_df = (
    df.groupby(["buyer_state", "buyer_county", df["transaction_date"].dt.year])["drug_qty"]
    .sum()
    .reset_index()
)

yearly_df.to_parquet(f"../20_outputs/all_shipments_{STATE}_yearly.parquet")

print("Export done.")