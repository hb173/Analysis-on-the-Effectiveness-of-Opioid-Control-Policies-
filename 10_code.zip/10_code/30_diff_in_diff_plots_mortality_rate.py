# To add a new cell, type '# %%'
# To add a new markdown cell, type '# %% [markdown]'
# %% [markdown]
# ### Plot Diff-in-Diff for Florida, Texas, and Washington

# %%
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
import matplotlib_inline
from analysis_functions import plot_diff_in_diff

matplotlib_inline.backend_inline.set_matplotlib_formats("svg")
plt.rcParams["font.size"] = 12

# %%
#           changed to 20_out vvvvvvvvvvvv
fl_mortality = pd.read_csv("../20_outputs/fl_mortality.csv", sep=",", index_col=0)
tx_mortality = pd.read_csv("../20_outputs/tx_mortality.csv", sep=",", index_col=0)
wa_mortality = pd.read_csv("../20_outputs/wa_mortality.csv", sep=",", index_col=0)
mortality_compare_to_fl = pd.read_csv(
    "../20_outputs/Comparison/mortality_comparisons_for_fl.csv", sep=",", index_col=0
)
mortality_compare_to_tx = pd.read_csv(
    "../20_outputs/Comparison/mortality_comparisons_for_tx.csv", sep=",", index_col=0
)
mortality_compare_to_wa = pd.read_csv(
    "../20_outputs/Comparison/mortality_comparisons_for_wa.csv", sep=",", index_col=0
)


# %%
fl_mortality


# %%
mortality_compare_to_fl


# %%
mortality_compare_to_fl["County"].nunique()

# %% [markdown]
# #### Florida

# %%
# seperate to pre and post policy periods for FL and comparison states (average of PA, AR, NM)

x_pre_fl = np.array(fl_mortality[fl_mortality["Year"] <= 2010]["Year"])
y_pre_fl = np.array(fl_mortality[fl_mortality["Year"] <= 2010]["Mortality Rate"])
x_post_fl = np.array(fl_mortality[fl_mortality["Year"] >= 2010]["Year"])
y_post_fl = np.array(fl_mortality[fl_mortality["Year"] >= 2010]["Mortality Rate"])

x_pre_comp_fl = np.array(mortality_compare_to_fl[mortality_compare_to_fl["Year"] <= 2010]["Year"])
y_pre_comp_fl = np.array(
    mortality_compare_to_fl[mortality_compare_to_fl["Year"] <= 2010]["Mortality Rate"]
)
x_post_comp_fl = np.array(mortality_compare_to_fl[mortality_compare_to_fl["Year"] >= 2010]["Year"])
y_post_comp_fl = np.array(
    mortality_compare_to_fl[mortality_compare_to_fl["Year"] >= 2010]["Mortality Rate"]
)


# %%
# def plot_diff_in_diff(
#     State_ABBR,
#     x_pre,
#     y_pre,
#     x_post,
#     y_post,
#     x_pre_comp,
#     y_pre_comp,
#     x_post_comp,
#     y_post_comp,
#     policy_year,
#     ax=None,
# ):
#     import warnings

#     warnings.filterwarnings("ignore")

#     if ax is None:
#         fig, ax = plt.subplots(figsize=(8, 5))
#     sns.regplot(x_pre, y_pre, ci=95, color="r", scatter=False, ax=ax, label=State_ABBR)
#     sns.regplot(x_post, y_post, ci=95, color="r", scatter=False, ax=ax)
#     sns.regplot(x_pre_comp, y_pre_comp, ci=95, color="b", scatter=False, ax=ax, label="Comparison Group")
#     sns.regplot(x_post_comp, y_post_comp, ci=95, color="b", scatter=False, ax=ax)
#     fig.legend(loc="lower right")
#     # Axes labels
#     ax.set_xlabel("Year")
#     ax.set_ylabel("Avg. Mortality Rate")
#     ax.set_title(State_ABBR + " Diff-in-Diff Model Graph", weight="bold")
#     ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda y, _: "{:.4%}".format(y)))

#     # add elements
#     ax.axvline(x=policy_year, color="black", ls="--")
#     ax.text(policy_year + 0.1, y_post.mean() * 0.80, "Policy Change", fontsize=12)
#     ax.text(2003.3, y_pre.mean() * 0.8, "CI: 95%", fontsize=10)
#     # ax.text(
#     #     2006, y_pre_comp.mean() * 1.15, "Comparison Group", weight="bold", color="b", ha="center"
#     # )
#     # ax.text(2006, y_pre.mean() * 1.15, State_ABBR, weight="bold", color="r", ha="center")
#     ax.grid(b=True, which="major", color="#999999", linestyle="-", alpha=0.2)

#     # ax.legend(loc="upper left")
#     sns.despine()
#     plt.tight_layout()
#     plt.savefig(f"../20_outputs/DiffInDiff_{State_ABBR}.png", dpi=300, facecolor="w")
#     plt.show()


plot_diff_in_diff(
    "FL",
    x_pre_fl,
    y_pre_fl,
    x_post_fl,
    y_post_fl,
    x_pre_comp_fl,
    y_pre_comp_fl,
    x_post_comp_fl,
    y_post_comp_fl,
    2010,
)

# %% [markdown]
# ### Texas

# %%
# seperate to pre and post policy periods for TX and comparison states (average of CO, ID, MI)

x_pre_tx = np.array(tx_mortality[tx_mortality["Year"] < 2007]["Year"])
y_pre_tx = np.array(tx_mortality[tx_mortality["Year"] < 2007]["Mortality Rate"])
x_post_tx = np.array(tx_mortality[tx_mortality["Year"] >= 2007]["Year"])
y_post_tx = np.array(tx_mortality[tx_mortality["Year"] >= 2007]["Mortality Rate"])

x_pre_comp_tx = np.array(mortality_compare_to_tx[mortality_compare_to_tx["Year"] < 2007]["Year"])
y_pre_comp_tx = np.array(
    mortality_compare_to_tx[mortality_compare_to_tx["Year"] < 2007]["Mortality Rate"]
)
x_post_comp_tx = np.array(mortality_compare_to_tx[mortality_compare_to_tx["Year"] >= 2007]["Year"])
y_post_comp_tx = np.array(
    mortality_compare_to_tx[mortality_compare_to_tx["Year"] >= 2007]["Mortality Rate"]
)


# %%
plot_diff_in_diff(
    "TX",
    x_pre_tx,
    y_pre_tx,
    x_post_tx,
    y_post_tx,
    x_pre_comp_tx,
    y_pre_comp_tx,
    x_post_comp_tx,
    y_post_comp_tx,
    2007,
)

# %% [markdown]
# #### Washington

# %%
# seperate to pre and post policy periods for WA and comparison states (average of OR, CA, NV)

x_pre_wa = np.array(wa_mortality[wa_mortality["Year"] < 2012]["Year"])
y_pre_wa = np.array(wa_mortality[wa_mortality["Year"] < 2012]["Mortality Rate"])
x_post_wa = np.array(wa_mortality[wa_mortality["Year"] >= 2012]["Year"])
y_post_wa = np.array(wa_mortality[wa_mortality["Year"] >= 2012]["Mortality Rate"])

x_pre_comp_wa = np.array(mortality_compare_to_wa[mortality_compare_to_wa["Year"] < 2012]["Year"])
y_pre_comp_wa = np.array(
    mortality_compare_to_wa[mortality_compare_to_wa["Year"] < 2012]["Mortality Rate"]
)
x_post_comp_wa = np.array(mortality_compare_to_wa[mortality_compare_to_wa["Year"] >= 2012]["Year"])
y_post_comp_wa = np.array(
    mortality_compare_to_wa[mortality_compare_to_wa["Year"] >= 2012]["Mortality Rate"]
)


# %%
plot_diff_in_diff(
    "WA",
    x_pre_wa,
    y_pre_wa,
    x_post_wa,
    y_post_wa,
    x_pre_comp_wa,
    y_pre_comp_wa,
    x_post_comp_wa,
    y_post_comp_wa,
    2012,
)
