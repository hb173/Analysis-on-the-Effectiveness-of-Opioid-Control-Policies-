import matplotlib.pyplot as plt
import seaborn as sns
import statsmodels.formula.api as smf
import pandas as pd
plt.rcParams["font.size"] = 14

def plot_pre_post(State_ABBR, x_pre, y_pre, x_post, y_post, policy_year, ax=None):
    import warnings
    warnings.filterwarnings("ignore")

    if ax is None:
        fig, ax = plt.subplots(figsize=(8, 5))


    x_pre = x_pre - policy_year
    x_post = x_post - policy_year

    sns.regplot(x_pre, y_pre, ci=95, scatter=False, color="r", ax=ax)
    # m, b = np.polyfit(x_post, y_post, 1)
    # plt.plot(x_post, m * x_post + b)
    sns.regplot(x_post, y_post, ci=95, scatter=False, color="r", ax=ax)
    ax.set_xlabel("Years from policy change")
    ax.set_ylabel("Mortality Rate")
    ax.set_title(State_ABBR + " Pre-Post Model Graph", weight="bold")
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda y, _: "{:.4%}".format(y)))

    ax.axvline(x=0, color="black", ls="--")
    ax.text(policy_year + 0.1, y_post.mean() * 0.80, "Policy Change", fontsize=12)
    ax.text(2003.2, y_pre.mean() * 1.1, "CI:95%", fontsize=10)

    ax.grid(b=True, which="major", color="#999999", linestyle="-", alpha=0.2)
    sns.despine()
    plt.tight_layout()
    # plt.show()



def plot_diff_in_diff(
    State_ABBR,
    x_pre,
    y_pre,
    x_post,
    y_post,
    x_pre_comp,
    y_pre_comp,
    x_post_comp,
    y_post_comp,
    policy_year,
    ax=None,
):
    import warnings

    warnings.filterwarnings("ignore")

    if ax is None:
        fig, ax = plt.subplots(figsize=(8, 5))
    sns.regplot(x_pre, y_pre, ci=95, color="r", scatter=False, ax=ax, label=State_ABBR)
    sns.regplot(x_post, y_post, ci=95, color="r", scatter=False, ax=ax)
    sns.regplot(x_pre_comp, y_pre_comp, ci=95, color="b", scatter=False, ax=ax, label="Comparison Group")
    sns.regplot(x_post_comp, y_post_comp, ci=95, color="b", scatter=False, ax=ax)
    ax.legend(loc="lower right")
    # Axes labels
    ax.set_xlabel("Year")
    ax.set_ylabel("Avg. Mortality Rate")
    ax.set_title(State_ABBR + " Diff-in-Diff Model Graph", weight="bold")
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda y, _: "{:.4%}".format(y)))

    # add elements
    ax.axvline(x=policy_year, color="black", ls="--")
    ax.text(policy_year + 0.1, y_post.mean() * 0.80, "Policy Change", fontsize=12)
    ax.text(2003.3, y_pre.mean() * 0.8, "CI: 95%", fontsize=10)
    # ax.text(
    #     2006, y_pre_comp.mean() * 1.15, "Comparison Group", weight="bold", color="b", ha="center"
    # )
    # ax.text(2006, y_pre.mean() * 1.15, State_ABBR, weight="bold", color="r", ha="center")
    ax.grid(b=True, which="major", color="#999999", linestyle="-", alpha=0.2)

    # ax.legend(loc="upper left")
    sns.despine()
    plt.tight_layout()
    # plt.savefig(f"../20_outputs/DiffInDiff_{State_ABBR}.png", dpi=300, facecolor="w")
    # plt.show()


policyyear = {"fl": 2010, "tx": 2007, "wa": 2012}

def regression_mortality(state_abbr):
    state_abbr = state_abbr.lower()
    state = pd.read_csv(f"../20_outputs/{state_abbr}_mortality.csv", sep=",", index_col=0)
    compare = pd.read_csv(
    f"../20_outputs/Comparison/mortality_comparisons_for_{state_abbr}.csv", sep=",", index_col=0
)
    assert (state.columns == compare.columns).all
    combined = pd.concat([state, compare]).drop("_merge", axis = 1)
    combined["Post"] = combined["Year"] >= policyyear[f"{state_abbr}"]
    combined["Policy_State"] = combined["State"] == f"{state_abbr.upper()}"
    combined["Year"] = combined["Year"] - policyyear[f"{state_abbr}"] # normalize policy as t=0
    combined = combined.rename(columns={"Mortality Rate": "Mortality_Rate"})
    model = smf.ols("Mortality_Rate ~ Year*Post*Policy_State", data=combined).fit()
    
    return combined, model.summary()

def regression_shipment(state_abbr):
    state_abbr = state_abbr.lower()
    state = pd.read_parquet(f"../20_outputs/all_shipments_{state_abbr.upper()}_yearly.parquet")
    state["Post"] = state["transaction_date"] >= policyyear[f"{state_abbr}"]
    state["Policy_State"] = state["buyer_state"] == f"{state_abbr.upper()}"
    state["Year"] = state["transaction_date"] - policyyear[f"{state_abbr}"] # normalize policy as t=0
    model = smf.ols("drug_qty ~ Year*Post*Policy_State", data=state).fit()
    return model.summary()