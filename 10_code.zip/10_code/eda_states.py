#%% 
# Importing libraries
import pandas as pd
import numpy as np
from dataCleaningFunctions import *
import os.path
from os import path
import matplotlib.pyplot as plt
import seaborn as sns

#%%
########################### SETTING THINGS UP ###########################

# read state data
fl_mortality = pd.read_csv("../20_outputs/fl_mortality.csv", sep=",", index_col=0)
tx_mortality = pd.read_csv("../20_outputs/tx_mortality.csv", sep=",", index_col=0)
wa_mortality = pd.read_csv("../20_outputs/wa_mortality.csv", sep=",", index_col=0)

#%%
# Function that reads in population data from 00_source
# base_state_abbr must be uppercase (eg. FL for Florida)
# state_abbr must be lowercase (eg. fl for Florida)
def read_state_population(base_state_abbr, state_abbr):
    root_path = (
        "../00_source_data/Population/" + base_state_abbr + "_and_comparison_states/" + state_abbr
    )
    path00_1 = root_path + "_pop_2000-2009.xls"
    path00_2 = root_path + "_pop_2000-2009.xlsx"
    if path.exists(path00_1):
        state00 = pd.read_excel(path00_1, header=[3])
    elif path.exists(path00_2):
        state00 = pd.read_excel(path00_2, header=[3])
    else:
        print("File for state00 not found.")

    path10_1 = root_path + "_pop_2010-2019.xls"
    path10_2 = root_path + "_pop_2010-2019.xlsx"
    if path.exists(path10_1):
        state10 = pd.read_excel(path10_1, header=[3])
    elif path.exists(path10_2):
        state10 = pd.read_excel(path10_2, header=[3])
    return state00, state10

#%%
# Load Mortality data from 2003 to 2015
base_path = "../00_source_data/US_VitalStatistics/Underlying Cause of Death, "
years_data = []
for i in range(2003, 2016):
    file_path = base_path + str(i) + ".txt"
    death_data = pd.read_csv(
        file_path,
        error_bad_lines=False,
        sep="\t",
    )
    years_data.append(death_data)

df_raw_mortality = pd.concat(years_data, ignore_index=True)

def create_merged_from_raw(basestate_abbr, state_abbr, df_raw_mortality):
    state00pop, state10pop = read_state_population(basestate_abbr, state_abbr)
    State_ABBR = state_abbr.upper()
    state_pop = clean_pop(state00pop,state10pop,State_ABBR)
    state_mortality = clean_mortality(df_raw_mortality, state_abbr.upper())
    state_merged = merge_mortalitypop(state_mortality, state_pop)
    return state_merged

def plot_diff_in_diff(
    State_ABBR,
    x_pre,
    y_pre,
    x_post,
    y_post,
    x_pre_comp,
    y_pre_comp,
    x_post_comp,
    y_post_comp,
    policy_year,
):
    import warnings

    warnings.filterwarnings("ignore")

    fig, ax = plt.subplots(figsize=(8, 5))
    sns.regplot(x_pre, y_pre, ci=95, color="r", scatter=False, ax=ax)
    sns.regplot(x_post, y_post, ci=95, color="r", scatter=False, ax=ax)
    sns.regplot(x_pre_comp, y_pre_comp, ci=95, color="b", scatter=False, ax=ax)
    sns.regplot(x_post_comp, y_post_comp, ci=95, color="b", scatter=False, ax=ax)

    # Axes labels
    ax.set_xlabel("Year")
    ax.set_ylabel("Avg. Mortality Rate")
    ax.set_title(State_ABBR + " Diff-in-Diff Model Graph", weight="bold")
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda y, _: "{:.4%}".format(y)))

    # add elements
    ax.axvline(x=policy_year, color="black", ls="--")
    ax.text(policy_year + 0.1, y_post.mean() * 0.80, "Policy Change", fontsize=12)
    ax.text(2003.3, y_pre.mean() * 0.8, "CI: 95%", fontsize=10)
    ax.text(
        2006, y_pre_comp.mean() * 1, "Comparison Group", weight="bold", color="b", ha="center"
    )
    ax.text(2006, y_pre.mean() * 1.15, State_ABBR, weight="bold", color="r", ha="center")
    ax.grid(b=True, which="major", color="#999999", linestyle="-", alpha=0.2)

    # ax.legend(loc="upper left")
    sns.despine()
    plt.show()

#%%
# read in comparison states table
states = pd.read_csv("./qualitative_support/comparison-state-selection.csv")
states = states.iloc[:np.where(states["Non-Policy States (Name)"].isnull())[0][0], :]
states = states.fillna(0)

##################### LOOK AT TX COMPARISON STATES ######################

#%%
# Look at TX comparison states
states.loc[states["TX compare"] == 1, "Non-Policy States"]

#%%
# examine each of the five probable states
ar = create_merged_from_raw("TX", "ar", df_raw_mortality) #not good
ga = create_merged_from_raw("TX", "ga", df_raw_mortality) #good
il = create_merged_from_raw("TX", "il", df_raw_mortality) #very good
ks = create_merged_from_raw("TX", "ks", df_raw_mortality) #very good
nm = create_merged_from_raw("TX", "nm", df_raw_mortality) #bleh

#%%
# concat to use average of the 3 best states: GA, KS, IL
txcomparisons = pd.concat([ga, ks, il], ignore_index=True)

#%%
# plot the comparison plots
x_pre_tx = np.array(tx_mortality[tx_mortality["Year"] < 2007]["Year"])
y_pre_tx = np.array(tx_mortality[tx_mortality["Year"] < 2007]["Mortality Rate"])
x_post_tx = np.array(tx_mortality[tx_mortality["Year"] >= 2007]["Year"])
y_post_tx = np.array(tx_mortality[tx_mortality["Year"] >= 2007]["Mortality Rate"])

x_pre_comp_tx = np.array(txcomparisons[txcomparisons["Year"] < 2007]["Year"])
y_pre_comp_tx = np.array(
    txcomparisons[txcomparisons["Year"] < 2007]["Mortality Rate"]
)
x_post_comp_tx = np.array(txcomparisons[txcomparisons["Year"] >= 2007]["Year"])
y_post_comp_tx = np.array(
    txcomparisons[txcomparisons["Year"] >= 2007]["Mortality Rate"]
)

plot_diff_in_diff(
    "TX",
    x_pre_tx,
    y_pre_tx,
    x_post_tx,
    y_post_tx,
    x_pre_comp_tx,
    y_pre_comp_tx,
    x_post_comp_tx,
    y_post_comp_tx,
    2007,
)

##################### LOOK AT WA COMPARISON STATES ######################
#%%
# Look at WA comparison states
states.loc[states["WA compare"] == 1, "Non-Policy States"]

#%%
# examine each of the five probable states
ca = create_merged_from_raw("WA", "ca", df_raw_mortality) #good
il = create_merged_from_raw("WA", "il", df_raw_mortality) #very good
ks = create_merged_from_raw("WA", "ks", df_raw_mortality) #not good but better
nm = create_merged_from_raw("WA", "nm", df_raw_mortality) #not good
sd = create_merged_from_raw("WA", "sd", df_raw_mortality) #very not good

#%%
# concat to use average of the 3 best states: GA, KS, IL
wacomparisons = pd.concat([ca, il, ks], ignore_index=True)

#%%
# plot the comparison plots
x_pre_wa = np.array(wa_mortality[wa_mortality["Year"] < 2012]["Year"])
y_pre_wa = np.array(wa_mortality[wa_mortality["Year"] < 2012]["Mortality Rate"])
x_post_wa = np.array(wa_mortality[wa_mortality["Year"] >= 2012]["Year"])
y_post_wa = np.array(wa_mortality[wa_mortality["Year"] >= 2012]["Mortality Rate"])

x_pre_comp_wa = np.array(wacomparisons[wacomparisons["Year"] < 2012]["Year"])
y_pre_comp_wa = np.array(
    wacomparisons[wacomparisons["Year"] < 2012]["Mortality Rate"]
)
x_post_comp_wa = np.array(wacomparisons[wacomparisons["Year"] >= 2012]["Year"])
y_post_comp_wa = np.array(
    wacomparisons[wacomparisons["Year"] >= 2012]["Mortality Rate"]
)

plot_diff_in_diff(
    "WA",
    x_pre_wa,
    y_pre_wa,
    x_post_wa,
    y_post_wa,
    x_pre_comp_wa,
    y_pre_comp_wa,
    x_post_comp_wa,
    y_post_comp_wa,
    2012,
)
