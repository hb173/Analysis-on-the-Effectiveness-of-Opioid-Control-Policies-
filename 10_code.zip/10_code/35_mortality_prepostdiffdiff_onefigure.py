#%%
import pandas as pd
import numpy as np
from analysis_functions import plot_pre_post, plot_diff_in_diff
import matplotlib.pyplot as plt
import seaborn as sns

#%%
fl_mortality = pd.read_csv("../20_outputs/fl_mortality.csv", sep=",", index_col=0)
tx_mortality = pd.read_csv("../20_outputs/tx_mortality.csv", sep=",", index_col=0)
wa_mortality = pd.read_csv("../20_outputs/wa_mortality.csv", sep=",", index_col=0)
mortality_compare_to_fl = pd.read_csv(
    "../20_outputs/Comparison/mortality_comparisons_for_fl.csv", sep=",", index_col=0
)
mortality_compare_to_tx = pd.read_csv(
    "../20_outputs/Comparison/mortality_comparisons_for_tx.csv", sep=",", index_col=0
)
mortality_compare_to_wa = pd.read_csv(
    "../20_outputs/Comparison/mortality_comparisons_for_wa.csv", sep=",", index_col=0
)

########################### FLORIDA #############################
x_pre_fl = np.array(fl_mortality[fl_mortality["Year"] < 2010]["Year"])
y_pre_fl = np.array(fl_mortality[fl_mortality["Year"] < 2010]["Mortality Rate"])
x_post_fl = np.array(fl_mortality[fl_mortality["Year"] >= 2010]["Year"])
y_post_fl = np.array(fl_mortality[fl_mortality["Year"] >= 2010]["Mortality Rate"])

x_pre_comp_fl = np.array(mortality_compare_to_fl[mortality_compare_to_fl["Year"] < 2010]["Year"])
y_pre_comp_fl = np.array(
    mortality_compare_to_fl[mortality_compare_to_fl["Year"] < 2010]["Mortality Rate"]
)
x_post_comp_fl = np.array(mortality_compare_to_fl[mortality_compare_to_fl["Year"] >= 2010]["Year"])
y_post_comp_fl = np.array(
    mortality_compare_to_fl[mortality_compare_to_fl["Year"] >= 2010]["Mortality Rate"]
)

fig, axes = plt.subplots(1, 2, figsize=(16, 5))
plot_pre_post("FL", x_pre_fl, y_pre_fl, x_post_fl, y_post_fl, 2010, ax=axes[0])
plot_diff_in_diff(
    "FL",
    x_pre_fl,
    y_pre_fl,
    x_post_fl,
    y_post_fl,
    x_pre_comp_fl,
    y_pre_comp_fl,
    x_post_comp_fl,
    y_post_comp_fl,
    2010,
    ax=axes[1],
)

plt.savefig("../20_outputs/plots/FL_mortality_prepostdiffdiff_onefigure.png", facecolor="white", dpi=300)
sns.despine()
plt.tight_layout()
plt.close()

#%%
########################### TEXAS #############################
x_pre_tx = np.array(tx_mortality[tx_mortality["Year"] < 2007]["Year"])
y_pre_tx = np.array(tx_mortality[tx_mortality["Year"] < 2007]["Mortality Rate"])
x_post_tx = np.array(tx_mortality[tx_mortality["Year"] >= 2007]["Year"])
y_post_tx = np.array(tx_mortality[tx_mortality["Year"] >= 2007]["Mortality Rate"])

x_pre_comp_tx = np.array(mortality_compare_to_tx[mortality_compare_to_tx["Year"] < 2007]["Year"])
y_pre_comp_tx = np.array(
    mortality_compare_to_tx[mortality_compare_to_tx["Year"] < 2007]["Mortality Rate"]
)
x_post_comp_tx = np.array(mortality_compare_to_tx[mortality_compare_to_tx["Year"] >= 2007]["Year"])
y_post_comp_tx = np.array(
    mortality_compare_to_tx[mortality_compare_to_tx["Year"] >= 2007]["Mortality Rate"]
)

fig, axes = plt.subplots(1, 2, figsize=(16, 5))
plot_pre_post("TX", x_pre_tx, y_pre_tx, x_post_tx, y_post_tx, 2007, ax=axes[0])
plot_diff_in_diff(
    "TX",
    x_pre_tx,
    y_pre_tx,
    x_post_tx,
    y_post_tx,
    x_pre_comp_tx,
    y_pre_comp_tx,
    x_post_comp_tx,
    y_post_comp_tx,
    2007,
    ax=axes[1],
)

plt.savefig("../20_outputs/plots/TX_mortality_prepostdiffdiff_onefigure.png", facecolor="white", dpi=300)
sns.despine()
plt.tight_layout()
plt.close()

#%%
x_pre_wa = np.array(wa_mortality[wa_mortality["Year"] < 2012]["Year"])
y_pre_wa = np.array(wa_mortality[wa_mortality["Year"] < 2012]["Mortality Rate"])
x_post_wa = np.array(wa_mortality[wa_mortality["Year"] >= 2012]["Year"])
y_post_wa = np.array(wa_mortality[wa_mortality["Year"] >= 2012]["Mortality Rate"])

x_pre_comp_wa = np.array(mortality_compare_to_wa[mortality_compare_to_wa["Year"] < 2012]["Year"])
y_pre_comp_wa = np.array(
    mortality_compare_to_wa[mortality_compare_to_wa["Year"] < 2012]["Mortality Rate"]
)
x_post_comp_wa = np.array(mortality_compare_to_wa[mortality_compare_to_wa["Year"] >= 2012]["Year"])
y_post_comp_wa = np.array(
    mortality_compare_to_wa[mortality_compare_to_wa["Year"] >= 2012]["Mortality Rate"]
)


########################### WASHINGTON #############################
fig, axes = plt.subplots(1, 2, figsize=(16, 5))
plot_pre_post("WA", x_pre_wa, y_pre_wa, x_post_wa, y_post_wa, 2012, ax=axes[0])
plot_diff_in_diff(
    "WA",
    x_pre_wa,
    y_pre_wa,
    x_post_wa,
    y_post_wa,
    x_pre_comp_wa,
    y_pre_comp_wa,
    x_post_comp_wa,
    y_post_comp_wa,
    2012,
    ax=axes[1],
)

plt.savefig("../20_outputs/plots/WA_mortality_prepostdiffdiff_onefigure.png", facecolor="white", dpi=300)
sns.despine()
plt.tight_layout()
plt.close()
