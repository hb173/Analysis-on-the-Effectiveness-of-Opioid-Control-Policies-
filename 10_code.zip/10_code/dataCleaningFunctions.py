import pandas as pd
import numpy as np
from os import path


# Function that concatenates all the mortality datas
def read_concat_mortality():
    import warnings

    warnings.filterwarnings("ignore")
    all_mortality = []
    for year in range(2003, 2016):
        all_mortality.append(
            pd.read_csv(
                "../00_source_data/US_VitalStatistics/Underlying Cause of Death, "
                + str(year)
                + ".txt",
                error_bad_lines=False,
                sep="\t",
            )
        )
    return pd.concat(all_mortality, ignore_index=True)


# Function that reads in population data for the desired states
def read_state_population(base_state_abbr, state_abbr):
    root_path = (
        "../00_source_data/Population/" + base_state_abbr + "_and_comparison_states/" + state_abbr
    )
    path00_1 = root_path + "_pop_2000-2009.xls"
    path00_2 = root_path + "_pop_2000-2009.xlsx"
    if path.exists(path00_1):
        state00 = pd.read_excel(path00_1, header=[3])
    elif path.exists(path00_2):
        state00 = pd.read_excel(path00_2, header=[3])
    else:
        print("File for state00 not found.")

    path10_1 = root_path + "_pop_2010-2019.xls"
    path10_2 = root_path + "_pop_2010-2019.xlsx"
    if path.exists(path10_1):
        state10 = pd.read_excel(path10_1, header=[3])
    elif path.exists(path10_2):
        state10 = pd.read_excel(path10_2, header=[3])
    return state00, state10
  

# Function that cleans the population data for a given state
def clean_pop(df1, df2, State_ABBR):
    df1 = df1.drop(["Unnamed: 1", 2000, 2001, 2002, "Unnamed: 12", "Unnamed: 13"], axis=1)
    df1 = df1.rename(columns={"Unnamed: 0": "County"})
    df2 = df2.drop(["Census", "Estimates Base", 2016, 2017, 2018, 2019], axis=1)
    df2 = df2.rename(columns={"Unnamed: 0": "County"})
    df1.drop(df1.head(1).index, inplace=True)
    df1.drop(df1.tail(8).index, inplace=True)
    df2.drop(df2.head(1).index, inplace=True)
    df2.drop(df2.tail(5).index, inplace=True)
    df1["County"] = df1["County"].str[1:]
    df2["County"] = df2["County"].str[1:]
    df1 = df1.melt(id_vars=["County"])
    df1 = df1.rename(columns={"variable": "Year", "value": "Population"})
    df1 = df1.groupby(["Year", "County"], as_index=False).sum()
    df2 = df2.melt(id_vars=["County"])
    df2 = df2.rename(columns={"variable": "Year", "value": "Population"})
    df2 = df2.groupby(["Year", "County"], as_index=False).sum()
    df2[["County1", "State"]] = df2.County.str.split(", ", expand=True)
    df2 = df2.drop(["County", "State"], axis=1)
    df2 = df2.rename(columns={"County1": "County"})
    df_concat = pd.concat([df1, df2], ignore_index=True)
    df_concat["State"] = State_ABBR
    return df_concat


# Function to clean the mortality for a given state (Calls cleanpop)
def clean_mortality(df, State_Abbr):
    DEATH_CODES_USED = ["D1", "D2", "D4", "D9"]
    # cleanup
    df[["County1", "State"]] = df.County.str.split(", ", expand=True)
    df = df[df["State"] == State_Abbr]
    df = df.drop(["Notes", "County", "County Code", "Year Code"], axis=1)
    df = df.rename(columns={"County1": "County"})

    # subset, dtype fix & grouping
    df = df.query("`Drug/Alcohol Induced Cause Code`.isin(@DEATH_CODES_USED)", engine="python")
    df["Deaths"] = df["Deaths"].astype(float)
    df = df.groupby(["Year", "State", "County"], as_index=False).sum()
    df["Year"] = df["Year"].astype(int)
    return df


# Function that merges population data with mortality data
def merge_mortalitypop(df_mortality, df_pop):
    df_pop["County"] = df_pop["County"].astype("string")
    df_pop["State"] = df_pop["State"].astype("string")
    df_mortality["County"] = df_mortality["County"].astype("string")
    df_mortality["State"] = df_mortality["State"].astype("string")
    merged = df_mortality.merge(
        df_pop, left_on=["Year", "County"], right_on=["Year", "County"], how="right", indicator=True
    )
    merged = merged.drop(["State_x"], axis=1)
    merged = merged.rename(columns={"State_y": "State"})
    # merged["Deaths"] = merged["Deaths"].apply(
    #     lambda l: l if not np.isnan(l) else np.random.randint(0, 9)
    # )
    # merged["Deaths"] = merged["Deaths"].fillna(0)  # do not impute
    merged = merged.dropna(subset=["Deaths"])
    merged["Mortality Rate"] = merged["Deaths"] / merged["Population"]
    return merged


# Function that groups dataframe by year, and calculate the total death and total population
def calc_avg_mortality(df1, df2, df3):
    df1 = df1.groupby("Year", as_index=False).sum()[["Year", "Deaths", "Population"]]
    df2 = df2.groupby("Year", as_index=False).sum()[["Year", "Deaths", "Population"]]
    df3 = df3.groupby("Year", as_index=False).sum()[["Year", "Deaths", "Population"]]

    df = pd.concat([df1, df2, df3], ignore_index=True)
    df = df.groupby("Year", as_index=False).sum()
    df["Avg Mortality Rate"] = df["Deaths"] / df["Population"]
    return df
