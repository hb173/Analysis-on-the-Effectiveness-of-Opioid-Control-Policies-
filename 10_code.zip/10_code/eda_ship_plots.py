#%%
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from dataCleaningFunctions import *
import matplotlib_inline
plt.rcParams['font.size'] = 14

matplotlib_inline.backend_inline.set_matplotlib_formats("svg")

# states = ["FL", "NM", "IL", "WI", "MS", "GA"]
STATE = "FL"
policy_change = {"FL": 2010, "WA": 2012}
policy_change_year = policy_change[STATE]


if STATE == "FL":
    print("Using FL!")
    comparison_states = ["FL", "IL", "MS", "GA"]
else:
    print("Using WA!")
    comparison_states = ["WA", "IL", "KS", "CA"]  # missing: CA
    
#%%
yearly_df = pd.read_parquet(f"../20_outputs/all_shipments_{STATE}_yearly.parquet")

# Only use 3 states
yearly_df = yearly_df[yearly_df["buyer_state"].isin(comparison_states)]


#%%
pop_dfs = []
for comp_state in [x.lower() for x in comparison_states]:
    pop_pre_policy = pd.read_excel(
        f"../00_source_data/Population/{STATE}_and_comparison_states/{comp_state}_pop_2000-2009.xls",
        header=[3],
    )
    pop_post_policy = pd.read_excel(
        f"../00_source_data/Population/{STATE}_and_comparison_states/{comp_state}_pop_2010-2019.xlsx",
        header=[3],
    )
    pop = clean_pop(pop_pre_policy, pop_post_policy, comp_state.upper())
    pop = pop.assign(County=pop["County"].str.replace(" County", "").str.upper())
    pop_dfs.append(pop)

#%%
# pd.concat(pop_dfs)
#%%

yearly_df = pd.merge(
    yearly_df,
    pd.concat(pop_dfs),
    left_on=["buyer_state", "buyer_county", "transaction_date"],
    right_on=["State", "County", "Year"],
    how="left",
    # indicator=True,
)

yearly_df = yearly_df.assign(drugs_per_cap=yearly_df["drug_qty"] / yearly_df["Population"])

#%%
######################## PLOTTING POLICY CHANGE DIFFDIFF ###############################
fig, ax = plt.subplots(figsize=(9, 5))

# PRE
sns.regplot(
    data=yearly_df.query("transaction_date < @policy_change_year and buyer_state == @STATE"),
    x="transaction_date",
    y="drugs_per_cap",
    scatter=False,
    ci=95,
    color="r",
    ax=ax,
    label="Comparison Group",
    x_estimator=np.mean,
)


# POST
sns.regplot(
    data=yearly_df.query("transaction_date >= @policy_change_year and buyer_state == @STATE"),
    x="transaction_date",
    y="drugs_per_cap",
    scatter=False,
    ci=95,
    color="r",
    ax=ax,
)

ax.set_ylabel("Amount of Drugs (MME) per Capita")
ax.set_xlabel("Year")
ax.set_title(f"{STATE} Drug Prescription (MME) per Capita over time", weight="bold")
ax.axvline(x=policy_change_year, color="black", ls="--")
sns.despine()
plt.savefig(
    f"../20_outputs/plots/{STATE}_shipments_prepost.png", dpi=300, facecolor="w", edgecolor="w"
)


#%%
######################## PLOTTING POLICY CHANGE DIFFDIFF ###############################
fig, ax = plt.subplots(figsize=(8, 5))

# Control PRE
sns.regplot(
    data=yearly_df.query("transaction_date < @policy_change_year and buyer_state != @STATE"),
    x="transaction_date",
    y="drugs_per_cap",
    scatter=False,
    ci=95,
    color="b",
    ax=ax,
    label="Comparison Group",
    x_estimator=np.mean,
)


# Control POST
sns.regplot(
    data=yearly_df.query("transaction_date >= @policy_change_year and buyer_state != @STATE"),
    x="transaction_date",
    y="drugs_per_cap",
    scatter=False,
    ci=95,
    color="b",
    ax=ax,
)

# Treatment PRE
sns.regplot(
    data=yearly_df.query("transaction_date < @policy_change_year and buyer_state == @STATE"),
    x="transaction_date",
    y="drugs_per_cap",
    scatter=False,
    ci=95,
    color="r",
    ax=ax,
    label=STATE,
)

# Treatment POST
sns.regplot(
    data=yearly_df.query("transaction_date >= @policy_change_year and buyer_state == @STATE"),
    x="transaction_date",
    y="drugs_per_cap",
    scatter=False,
    ci=95,
    color="r",
    ax=ax,
)


# ax.set_xlim(xlim)

ax.legend()
ax.set_ylabel("Amount of Drugs (MME) per Capita")
ax.set_xlabel("Year")
ax.set_title(f"{STATE} Drug Prescription (MME) per Capita\nvs. Comparison States", weight="bold")
ax.axvline(x=policy_change_year, color="black", ls="--")
sns.despine()
plt.tight_layout()
plt.savefig(
    f"../20_outputs/plots/{STATE}_shipments_diffdiff.png", dpi=300, facecolor="w", edgecolor="w"
)
