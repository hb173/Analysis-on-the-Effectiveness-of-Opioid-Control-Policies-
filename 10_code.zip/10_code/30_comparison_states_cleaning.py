# %%
import pandas as pd
from dataCleaningFunctions import *
import os.path
from os import path

# %%
# Function that reads in population data from 00_source
# base_state_abbr must be uppercase (eg. FL for Florida)
# state_abbr must be lowercase (eg. fl for Florida)
def read_state_population(base_state_abbr, state_abbr):
    root_path = '../00_Source_data/Population/' + base_state_abbr + '_and_comparison_states/' + state_abbr
    path00_1 = root_path + '_pop_2000-2009.xls'
    path00_2 = root_path + '_pop_2000-2009.xlsx'
    if path.exists(path00_1):
        state00 = pd.read_excel(path00_1, header=[3])
    elif path.exists(path00_2):
        state00 = pd.read_excel(path00_2, header=[3])
        
    path10_1 = root_path + '_pop_2010-2019.xls'
    path10_2 = root_path + '_pop_2010-2019.xlsx'
    if path.exists(path10_1):
        state10 = pd.read_excel(path10_1, header=[3])
    elif path.exists(path10_2):
        state10 = pd.read_excel(path10_2, header=[3])
    return state00, state10

# %%
# Load Mortality data from 2003 to 2015
base_path = "../00_source_data/US_VitalStatistics/Underlying Cause of Death, "
years_data = []
for i in range(2003, 2016):
    file_path = base_path + str(i) + ".txt"
    death_data = pd.read_csv(file_path, error_bad_lines=False, sep="\t",)
    years_data.append(death_data)

# %%
df_raw_mortality = pd.concat(years_data,ignore_index=True)

# %%
# function that automates the three steps: cleaning population, cleaning mortality, merging
# returns a merged dataset
# basestate_abbr must be uppercase. state_abbr must be lowercase
def create_merged_from_raw(basestate_abbr, state_abbr, df_raw_mortality):
    state00pop, state10pop = read_state_population(basestate_abbr, state_abbr)
    State_ABBR = state_abbr.upper()
    state_pop = clean_pop(state00pop,state10pop,State_ABBR)
    state_mortality = clean_mortality(df_raw_mortality, state_abbr.upper())
    state_merged = merge_mortalitypop(state_mortality, state_pop)
    return state_merged

# %% [markdown]
# # States Compared to FL

# %% [markdown]
# ## Data Cleaning for Illinois

# %%
fl_il_merged = create_merged_from_raw('FL', 'il', df_raw_mortality)

# %%
fl_il_merged['County'].nunique()

# %% [markdown]
# ## Data Cleaning for Mississippi

# %%
fl_ms_merged = create_merged_from_raw('FL', 'ms', df_raw_mortality)

# %% [markdown]
# ## Data Cleaning for Georgia

# %%
fl_ga_merged = create_merged_from_raw('FL', 'ga', df_raw_mortality)

# %% [markdown]
# ## Data Cleaning for New Mexico

# %%
fl_nm_merged = create_merged_from_raw('FL', 'nm', df_raw_mortality)

# %% [markdown]
# ## Data Cleaning for Wisconsin

# %%
fl_wi_merged = create_merged_from_raw('FL', 'wi', df_raw_mortality)

# %% [markdown]
# # States Compared to TX

# %% [markdown]
# ## Data Cleaning for Illinois

# %%
tx_il_merged = create_merged_from_raw('TX', 'il', df_raw_mortality)

# %% [markdown]
# ## Data Cleaning for Georgia

# %%
tx_ga_merged = create_merged_from_raw('TX', 'ga', df_raw_mortality)

# %% [markdown]
# ## Data Cleaning for Arkansas

# %%
tx_ar_merged = create_merged_from_raw('TX', 'ar', df_raw_mortality)

# %% [markdown]
# ## Data Cleaning for Kansas

# %%
tx_ks_merged = create_merged_from_raw('TX', 'ks', df_raw_mortality)

# %% [markdown]
# ## Data Cleaning for New Mexico

# %%
tx_nm_merged = create_merged_from_raw('TX', 'nm', df_raw_mortality)

# %% [markdown]
# # States Compared to WA

# %% [markdown]
# ## Data Cleaning for Illinois

# %%
wa_il_merged = create_merged_from_raw('WA', 'il', df_raw_mortality)

# %% [markdown]
# ## Data Cleaning for Kansas

# %%
wa_ks_merged = create_merged_from_raw('WA', 'ks', df_raw_mortality)

# %% [markdown]
# ## Data Cleaning for New Mexico

# %%
wa_nm_merged = create_merged_from_raw('WA', 'nm', df_raw_mortality)

# %% [markdown]
# ## Data Cleaning for California

# %%
wa_ca_merged = create_merged_from_raw('WA', 'ca', df_raw_mortality)

# %% [markdown]
# ## Data Cleaning for South Dakota

# %%
wa_sd_merged = create_merged_from_raw('WA', 'sd', df_raw_mortality)

# %% [markdown]
# # Export to csv

# %%
fl_il_merged.to_csv(path_or_buf='../20_outputs/Comparison/fl_il_mortality.csv', sep=',')

# %%
fl_ms_merged.to_csv(path_or_buf='../20_outputs/Comparison/fl_ms_mortality.csv', sep=',')

# %%
fl_ga_merged.to_csv(path_or_buf='../20_outputs/Comparison/fl_ga_mortality.csv', sep=',')

# %%
fl_nm_merged.to_csv(path_or_buf='../20_outputs/Comparison/fl_nm_mortality.csv', sep=',')

# %%
fl_wi_merged.to_csv(path_or_buf='../20_outputs/Comparison/fl_wi_mortality.csv', sep=',')

# %%
tx_il_merged.to_csv(path_or_buf='../20_outputs/Comparison/tx_il_mortality.csv', sep=',')

# %%
tx_ks_merged.to_csv(path_or_buf='../20_outputs/Comparison/tx_ks_mortality.csv', sep=',')

# %%
tx_ga_merged.to_csv(path_or_buf='../20_outputs/Comparison/tx_ga_mortality.csv', sep=',')

# %%
tx_ar_merged.to_csv(path_or_buf='../20_outputs/Comparison/tx_ar_mortality.csv', sep=',')

# %%
tx_nm_merged.to_csv(path_or_buf='../20_outputs/Comparison/tx_nm_mortality.csv', sep=',')

# %%
wa_il_merged.to_csv(path_or_buf='../20_outputs/Comparison/wa_il_mortality.csv', sep=',')

# %%
wa_ks_merged.to_csv(path_or_buf='../20_outputs/Comparison/wa_ks_mortality.csv', sep=',')

# %%
wa_nm_merged.to_csv(path_or_buf='../20_outputs/Comparison/wa_nm_mortality.csv', sep=',')

# %%
wa_ca_merged.to_csv(path_or_buf='../20_outputs/Comparison/wa_ca_mortality.csv', sep=',')

# %%
wa_sd_merged.to_csv(path_or_buf='../20_outputs/Comparison/wa_sd_mortality.csv', sep=',')

# %% [markdown]
# # Mortality for three comparison states

# %% [markdown]
# ## Comparison states to FL

# %%
# Per EDA, we finalized the following states to compare to FL: GA, IL, MS
comparisons_fl = pd.concat([fl_il_merged, fl_ms_merged, fl_ga_merged], ignore_index=True)

# %% [markdown]
# ## Comparison states to TX

# %%
# Per EDA, we finalized the following states to compare to TX: GA, IL, KS
comparisons_tx = pd.concat([tx_il_merged, tx_ks_merged, tx_ga_merged], ignore_index=True)

# %% [markdown]
# ## Comparison states to WA

# %%
# Per EDA, we finalized the following states to compare to WA: CA, IL, KS
comparisons_wa = pd.concat([wa_il_merged, wa_ks_merged, wa_ca_merged], ignore_index=True)

# %% [markdown]
# ## Convert to csv

# %%
comparisons_fl.to_csv(path_or_buf='../20_outputs/Comparison/mortality_comparisons_for_fl.csv', sep=',')

# %%
comparisons_tx.to_csv(path_or_buf='../20_outputs/Comparison/mortality_comparisons_for_tx.csv', sep=',')

# %%
comparisons_wa.to_csv(path_or_buf='../20_outputs/Comparison/mortality_comparisons_for_wa.csv', sep=',')


