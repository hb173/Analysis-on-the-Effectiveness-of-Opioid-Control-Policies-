######################################################################################
######################### TO EXPLORE MEAN IMPUTATION OPTIONS #########################
######## DID NOT IMPLEMENT MEAN IMPUTATION DUE TO TOO LARGE % OF MISSING DATA ########
######################################################################################
#%%
import pandas as pd
import numpy as np
from dataCleaningFunctions import read_concat_mortality, read_state_population, clean_pop

#%%
df = read_concat_mortality()
State_Abbr = "TX"

#%%
def clean_mortality(df, State_Abbr):
    DEATH_CODES_USED = ["D1", "D2", "D4", "D9"]
    # cleanup
    df[["County1", "State"]] = df.County.str.split(", ", expand=True)
    df = df[df["State"] == State_Abbr]
    df = df.drop(["Notes", "County", "County Code", "Year Code"], axis=1)
    df = df.rename(columns={"County1": "County"})

    # subsetting for death codes related to drugs
    df = df.query("`Drug/Alcohol Induced Cause Code`.isin(@DEATH_CODES_USED)", engine="python")

    # merge with population to have states to impute
    state00pop, state10pop = read_state_population("TX", State_Abbr)
    state_pop = clean_pop(state00pop,state10pop,State_Abbr)
    df = df.merge(state_pop, on=["County", "Year"], how="right", indicator=True) # manually checked
    df = df.rename(columns={"State_y": "State"})
    df = df.drop(["State_x", "_merge"], axis=1)

    # dtype fix & group by
    df["Deaths"] = df["Deaths"].astype(float)
    df["Year"] = df["Year"].astype(int)
    # df = df.groupby(["Year", "State", "County"], as_index=False).sum()

    print(f"the number of N/As we have in 'Deaths' is {df['Deaths'].isna().sum()}")
    print(f"the percentage of that over total observations is {df['Deaths'].isna().sum()/len(df)}")

    # mean impute the missing values
    impute_df = df.groupby(["Year", "County", "State"], as_index=False).sum()
    impute_df["Mort_rate"] = impute_df["Deaths"] / impute_df["Population"]
    impute_df = impute_df.drop(["Deaths", "Population"],axis=1).groupby(["Year", "State"], as_index=False).mean()

    df['Deaths']=df['Deaths'].replace(0, np.nan)
    df = df.groupby(["Year", "State", "County"], as_index=False).sum()
    df = df.drop(["Population"], axis=1)

    return df, impute_df

#%%
# test data for functions
df_mortality, impute_df = clean_mortality(df, State_Abbr)
state00pop, state10pop = read_state_population("TX", State_Abbr)
df_pop = clean_pop(state00pop,state10pop,State_Abbr)

#%%
# Function that merges population data with mortality data
def merge_mortalitypop(df_mortality, df_pop, impute_df=None):
    df_pop["County"] = df_pop["County"].astype("string")
    df_pop["State"] = df_pop["State"].astype("string")
    df_mortality["County"] = df_mortality["County"].astype("string")
    df_mortality["State"] = df_mortality["State"].astype("string")
    merged = df_mortality.merge(
        df_pop, left_on=["Year", "County"], right_on=["Year", "County"], how="right", indicator=True)
    merged = merged.drop(["State_x"], axis=1)
    merged = merged.rename(columns={"State_y": "State"})
    # merged["Deaths"] = merged["Deaths"].apply(
    #     lambda l: l if not np.isnan(l) else np.random.randint(0, 9)
    # )
    # merged["Deaths"] = merged["Deaths"].fillna(0)  # do not impute
    merged["Mortality Rate"] = merged["Deaths"] / merged["Population"]

    #Add imputations for missing values
    merged['Mortality Rate']=merged['Mortality Rate'].replace(0, np.nan)
    if impute_df is not None:
        merged = merged.merge(impute_df, on=["Year", "State"], how="left")
        merged['Mortality Rate']=merged['Mortality Rate'].fillna(merged["Mort_rate"])
        merged = merged.drop(["Mort_rate"], axis=1)
    return merged

#%%
merge_mortalitypop(df_mortality, df_pop, impute_df)


#%%
states_interested = ["FL", "WA", "TX", "GA", "IL", "MS", "KS", ]

# %%

# anystate=merge_mortalitypop(df_mortality, df_pop, impute_df)
# anystate.to_csv(f"../20_outputs/Comparison/fl_{State_Abbr.lower()}_mortality.csv")

# # %%
# fl_il_merged= pd.read_csv("../20_outputs/Comparison/fl_il_mortality.csv", index_col=0)
# fl_ms_merged= pd.read_csv("../20_outputs/Comparison/fl_ms_mortality.csv", index_col=0)
# fl_ga_merged= pd.read_csv("../20_outputs/Comparison/fl_ga_mortality.csv", index_col=0)


# comparisons_fl = pd.concat([fl_il_merged, fl_ms_merged, fl_ga_merged], ignore_index=True)
# comparisons_fl.to_csv(path_or_buf='../20_outputs/Comparison/mortality_comparisons_for_fl.csv', sep=',')

# %%
